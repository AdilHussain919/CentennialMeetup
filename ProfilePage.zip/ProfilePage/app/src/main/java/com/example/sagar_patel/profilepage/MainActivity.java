package com.example.sagar_patel.profilepage;

import android.app.Activity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TabHost;
import android.widget.TextView;

public class MainActivity extends Activity {
    SQLiteDatabase dba;

    //
    private static final String tables[]={"tbl_users","tbl_friends"};
    //
    private static final String tableCreatorString[] ={"CREATE TABLE tbl_users (user_id INTEGER PRIMARY KEY AUTOINCREMENT ," +
            "centennial_id TEXT, firstname TEXT, lastname TEXT, address TEXT, email TEXT, DOB TEXT, hobby TEXT, program TEXT, origin TEXT, campus TEXT);",
            "CREATE TABLE tbl_friends (user_id INTEGER, friend_id INTEGER);"};
    public static TextView centId,fname,lname,email,address,hobby,dob,program,campus,origin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            centId = (TextView)findViewById(R.id.tv_id);
            fname  = (TextView)findViewById(R.id.tv_fn);
            lname = (TextView)findViewById(R.id.tv_ln);
            address  = (TextView)findViewById(R.id.tv_add);
            email = (TextView)findViewById(R.id.tv_email);
            dob  = (TextView)findViewById(R.id.tv_dob);
            hobby = (TextView)findViewById(R.id.tv_hobby);
            program  = (TextView)findViewById(R.id.tv_program);
            campus = (TextView)findViewById(R.id.tv_campus);
            origin = (TextView)findViewById(R.id.tv_origin) ;

        String cenId,firname,lasname,addre,emai,dob,hobb,progra,campu,origi;


            dba=openOrCreateDatabase("Clinic.db", SQLiteDatabase.CREATE_IF_NECESSARY,null);
            final DatabaseManager db = new DatabaseManager(this);
            //db.createDatabase(getApplicationContext());
            db.dbInitialize( tables,tableCreatorString);
            final String fields[] = {"user_id","centennial_id","firstname","lastname","address","email","dob","hobby","program","origin","campus"};
            final String record[] = new String[10];
            //Edit Text Fields
            //Add references to edit text fields bellow

            // Handle Save button
            // Add reference to add User button here

                        //retrieving info from edit text fields and putting into record array
                        record[1]="User1";
                        record[2]="amnsdns";
                        record[3]="sdsadadas";
                        record[4]="dsadasdsa";
                        record[5]="sdsadsads";
                        record[6]="sdsadsads";
                        record[7]="sdsadsd";
                        record[8]="sdsadsadsa";
                        record[9]="sdsadsdsd";
                        record[10]="dsadsadsadd";
                        //checking if added
                        Log.d("First Name: ",record[1]);
                        ContentValues values=new ContentValues();
                        //adding into database
                        values.put("centennial_id",record[1]);
                        values.put("firstname",record[2]);
                        values.put("lastname",record[3]);
                        values.put("address",record[4]);
                        values.put("email",record[5]);
                        values.put("dob",record[6]);
                        values.put("hobby",record[7]);
                        values.put("program",record[8]);
                        values.put("origin",record[9]);
                        values.put("campus",record[10]);

                        dba.insert("tbl_users",null,values);
                        dba.close();

                //    db.getStudentById(1);





            //Check UpdateRecord Method in database manager and create onClick method for Updating and Saving profile
            //Code for updating is similar to the code provided above


    }
}
